using System.Diagnostics.Eventing.Reader;
using System.Linq.Expressions;
using System.Reflection;
using System.Security.Cryptography;
using System.Windows.Forms;
using tictactoe;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace tictactoe
{
    public partial class Form1 : Form
    {
        Random r = new Random();

        // Random Numbers For Flags 
        int[] rn = new int[9];

        // Random Flag Country Name (from countriesList array)
        string[] rName = new string[9];

        // Random Flag Path 
        string[] rPath = new string[9];

        string pathEnd = ".svg";

        // Rest 
        bool turn = true; // true = x false = 0
        int turnCount = 0;

        // PictureBox define
        PictureBox[] pictureBoxes = new PictureBox[9];

        public Form1()
        {
            InitializeComponent();


            // random number for random flag selection

            rn[1] = r.Next(0, 191);
            do
            {
                rn[2] = r.Next(0, 190);
            } while (rn[2] == rn[1]);
            do
            {
                rn[3] = r.Next(0, 190);
            } while (rn[3] == rn[1] || rn[3] == rn[2]);

            do
            {
                rn[4] = r.Next(0, 190);
            } while (rn[4] == rn[1] || rn[4] == rn[2] || rn[4] == rn[3]);
            do
            {
                rn[5] = r.Next(0, 190);
            } while (rn[5] == rn[1] || rn[5] == rn[2] || rn[5] == rn[3] || rn[5] == rn[4]);
            do
            {
                rn[6] = r.Next(0, 190);
            } while (rn[6] == rn[1] || rn[6] == rn[2] || rn[6] == rn[3] || rn[6] == rn[4] || rn[6] == rn[5]);

            do
            {
                rn[7] = r.Next(0, 190);
            } while (rn[7] == rn[1] || rn[7] == rn[2] || rn[7] == rn[3] || rn[7] == rn[4] || rn[7] == rn[5] || rn[7] == rn[6]);
            do
            {
                rn[8] = r.Next(0, 190);
            } while (rn[8] == rn[7] || rn[8] == rn[2] || rn[8] == rn[3] || rn[8] == rn[4] || rn[8] == rn[5] || rn[8] == rn[6] || rn[8] == rn[7]);
            do
            {
                rn[9] = r.Next(0, 190);
            } while (rn[9] == rn[7] || rn[9] == rn[2] || rn[9] == rn[3] || rn[9] == rn[4] || rn[9] == rn[5] || rn[9] == rn[6] || rn[9] == rn[7] || rn[9] == rn[8]);



            // Random Number to Country Name
            for (int i = 0; i < rName.Length; i++)
            {
                rName[i] = CountryList.Countries[i];
            }

            // Random Number to .resx File
            for (int i = 0; i < rPath.Length; i++)
            {
                rPath[i] = rName[i] + pathEnd;
            }

            Image[] images = new Image[9];

            for (int i = 0; i < images.Length; i++)
            {
                images[i] = (Image)Properties.Resources.ResourceManager.GetObject(rPath[i]);
            }


            PictureBox[] pB = new PictureBox[9];

            for (int i = 0; i < pB.Length; i++)
            {
                pB[i].Image = images[i];
            }



        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            if (turn)
                b.Text = "X";
            else
                b.Text = "0";

            turnCount++;
            turn = !turn;
            b.Enabled = false;

            checkForWinner();
        }

        private void checkForWinner()
        {
            bool isWinner = false;

            if ((A1.Text == A2.Text) && (A2.Text == A3.Text) && (!A1.Enabled))
                isWinner = true;
            if ((B1.Text == B2.Text) && (B2.Text == B3.Text) && (!B1.Enabled))
                isWinner = true;
            if ((C1.Text == C2.Text) && (C2.Text == C3.Text) && (!C1.Enabled))
                isWinner = true;

            if ((A1.Text == B1.Text) && (B1.Text == C1.Text) && (!A1.Enabled))
                isWinner = true;
            if ((A2.Text == B2.Text) && (B2.Text == C2.Text) && (!A2.Enabled))
                isWinner = true;
            if ((A3.Text == B3.Text) && (B3.Text == C3.Text) && (!A3.Enabled))
                isWinner = true;

            if ((A1.Text == B2.Text) && (B2.Text == C3.Text) && (!A1.Enabled))
                isWinner = true;
            if ((C1.Text == B2.Text) && (B2.Text == A3.Text) && (!C1.Enabled))
                isWinner = true;

            if (isWinner)
            {
                disableButton();

                String winner = "";
                if (turn)
                {
                    winner = "0";
                    Standings0.Text = (Double.Parse(Standings0.Text) + 1).ToString();
                }
                else
                {
                    winner = "X";
                    StandingsX.Text = (Double.Parse(StandingsX.Text) + 1).ToString();
                }
                MessageBox.Show(winner + " wins", "Game ended");
            }
            else
            {
                if (turnCount == 9)
                {
                    StandingsX.Text = (Double.Parse(StandingsX.Text) + 0.5).ToString();
                    StandingsX.Text = (Double.Parse(StandingsX.Text) + 0.5).ToString();
                    MessageBox.Show("The game ended in a draw", "Game ended");
                }
            }
        }
        private void disableButton()
        {

            foreach (Control c in Controls)
            {
                try
                {
                    Button b = (Button)c;
                    b.Enabled = false;
                }
                catch { }
            }

        }

        private void newGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            turn = true;
            turnCount = 0;

            foreach (Control c in Controls)
            {
                try
                {
                    Button b = (Button)c;
                    b.Enabled = Enabled;
                    b.Text = "";
                }
                catch { }
            }
        }
        private void button_enter(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            if (b.Enabled)
            {
                if (turn)
                    b.Text = "X";
                else
                    b.Text = "0";
            }
        }
        private void button_leave(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            if (b.Enabled)
            {
                b.Text = "";
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}