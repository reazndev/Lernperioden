﻿namespace tictactoe
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            A1 = new Button();
            A2 = new Button();
            A3 = new Button();
            B3 = new Button();
            B2 = new Button();
            B1 = new Button();
            C3 = new Button();
            C2 = new Button();
            C1 = new Button();
            menuStrip1 = new MenuStrip();
            fileToolStripMenuItem = new ToolStripMenuItem();
            newGameToolStripMenuItem = new ToolStripMenuItem();
            exitToolStripMenuItem = new ToolStripMenuItem();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            StandingsX = new Label();
            Standings0 = new Label();
            pbA1 = new PictureBox();
            pbA2 = new PictureBox();
            pbA3 = new PictureBox();
            pbB1 = new PictureBox();
            pbB2 = new PictureBox();
            pbB3 = new PictureBox();
            pbC1 = new PictureBox();
            pbC2 = new PictureBox();
            pbC3 = new PictureBox();
            tbA1 = new TextBox();
            tbA2 = new TextBox();
            tbA3 = new TextBox();
            tbB2 = new TextBox();
            tbB1 = new TextBox();
            tbB3 = new TextBox();
            tbC1 = new TextBox();
            tbC2 = new TextBox();
            tbC3 = new TextBox();
            Input = new TextBox();
            dataGridView1 = new DataGridView();
            label4 = new Label();
            menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pbA1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbA2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbA3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbB1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbB2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbB3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbC1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbC2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pbC3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // A1
            // 
            A1.Font = new Font("Segoe UI", 30F, FontStyle.Regular, GraphicsUnit.Point);
            A1.Location = new Point(10, 20);
            A1.Margin = new Padding(3, 2, 3, 2);
            A1.Name = "A1";
            A1.Size = new Size(166, 142);
            A1.TabIndex = 0;
            A1.UseVisualStyleBackColor = true;
            A1.Click += button_Click;
            A1.MouseEnter += button_enter;
            A1.MouseLeave += button_leave;
            // 
            // A2
            // 
            A2.Font = new Font("Segoe UI", 30F, FontStyle.Regular, GraphicsUnit.Point);
            A2.Location = new Point(181, 20);
            A2.Margin = new Padding(3, 2, 3, 2);
            A2.Name = "A2";
            A2.Size = new Size(166, 142);
            A2.TabIndex = 1;
            A2.UseVisualStyleBackColor = true;
            A2.Click += button_Click;
            A2.MouseEnter += button_enter;
            A2.MouseLeave += button_leave;
            // 
            // A3
            // 
            A3.Font = new Font("Segoe UI", 30F, FontStyle.Regular, GraphicsUnit.Point);
            A3.Location = new Point(353, 20);
            A3.Margin = new Padding(3, 2, 3, 2);
            A3.Name = "A3";
            A3.Size = new Size(166, 142);
            A3.TabIndex = 2;
            A3.UseVisualStyleBackColor = true;
            A3.Click += button_Click;
            A3.MouseEnter += button_enter;
            A3.MouseLeave += button_leave;
            // 
            // B3
            // 
            B3.Font = new Font("Segoe UI", 30F, FontStyle.Regular, GraphicsUnit.Point);
            B3.Location = new Point(353, 166);
            B3.Margin = new Padding(3, 2, 3, 2);
            B3.Name = "B3";
            B3.Size = new Size(166, 142);
            B3.TabIndex = 5;
            B3.UseVisualStyleBackColor = true;
            B3.Click += button_Click;
            B3.MouseEnter += button_enter;
            B3.MouseLeave += button_leave;
            // 
            // B2
            // 
            B2.Font = new Font("Segoe UI", 30F, FontStyle.Regular, GraphicsUnit.Point);
            B2.Location = new Point(181, 166);
            B2.Margin = new Padding(3, 2, 3, 2);
            B2.Name = "B2";
            B2.Size = new Size(166, 142);
            B2.TabIndex = 4;
            B2.UseVisualStyleBackColor = true;
            B2.Click += button_Click;
            B2.MouseEnter += button_enter;
            B2.MouseLeave += button_leave;
            // 
            // B1
            // 
            B1.Font = new Font("Segoe UI", 30F, FontStyle.Regular, GraphicsUnit.Point);
            B1.Location = new Point(10, 166);
            B1.Margin = new Padding(3, 2, 3, 2);
            B1.Name = "B1";
            B1.Size = new Size(166, 142);
            B1.TabIndex = 3;
            B1.UseVisualStyleBackColor = true;
            B1.Click += button_Click;
            B1.MouseEnter += button_enter;
            B1.MouseLeave += button_leave;
            // 
            // C3
            // 
            C3.Font = new Font("Segoe UI", 30F, FontStyle.Regular, GraphicsUnit.Point);
            C3.Location = new Point(353, 314);
            C3.Margin = new Padding(3, 2, 3, 2);
            C3.Name = "C3";
            C3.Size = new Size(166, 142);
            C3.TabIndex = 8;
            C3.UseVisualStyleBackColor = true;
            C3.Click += button_Click;
            C3.MouseEnter += button_enter;
            C3.MouseLeave += button_leave;
            // 
            // C2
            // 
            C2.Font = new Font("Segoe UI", 30F, FontStyle.Regular, GraphicsUnit.Point);
            C2.Location = new Point(181, 314);
            C2.Margin = new Padding(3, 2, 3, 2);
            C2.Name = "C2";
            C2.Size = new Size(166, 142);
            C2.TabIndex = 7;
            C2.UseVisualStyleBackColor = true;
            C2.Click += button_Click;
            C2.MouseEnter += button_enter;
            C2.MouseLeave += button_leave;
            // 
            // C1
            // 
            C1.Font = new Font("Segoe UI", 30F, FontStyle.Regular, GraphicsUnit.Point);
            C1.Location = new Point(10, 314);
            C1.Margin = new Padding(3, 2, 3, 2);
            C1.Name = "C1";
            C1.Size = new Size(166, 142);
            C1.TabIndex = 6;
            C1.UseVisualStyleBackColor = true;
            C1.Click += button_Click;
            C1.MouseEnter += button_enter;
            C1.MouseLeave += button_leave;
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Padding = new Padding(5, 2, 0, 2);
            menuStrip1.Size = new Size(528, 24);
            menuStrip1.TabIndex = 9;
            menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { newGameToolStripMenuItem, exitToolStripMenuItem });
            fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            fileToolStripMenuItem.Size = new Size(37, 20);
            fileToolStripMenuItem.Text = "File";
            // 
            // newGameToolStripMenuItem
            // 
            newGameToolStripMenuItem.Name = "newGameToolStripMenuItem";
            newGameToolStripMenuItem.Size = new Size(132, 22);
            newGameToolStripMenuItem.Text = "New Game";
            newGameToolStripMenuItem.Click += newGameToolStripMenuItem_Click;
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new Size(132, 22);
            exitToolStripMenuItem.Text = "Exit";
            exitToolStripMenuItem.Click += exitToolStripMenuItem_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(12, 459);
            label1.Name = "label1";
            label1.Size = new Size(25, 28);
            label1.TabIndex = 10;
            label1.Text = "X";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(13, 481);
            label2.Name = "label2";
            label2.Size = new Size(24, 28);
            label2.TabIndex = 11;
            label2.Text = "0";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(31, 458);
            label3.Name = "label3";
            label3.Size = new Size(17, 28);
            label3.TabIndex = 12;
            label3.Text = ":";
            label3.Click += label3_Click;
            // 
            // StandingsX
            // 
            StandingsX.AutoSize = true;
            StandingsX.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            StandingsX.Location = new Point(43, 458);
            StandingsX.Name = "StandingsX";
            StandingsX.Size = new Size(23, 28);
            StandingsX.TabIndex = 13;
            StandingsX.Text = "0";
            // 
            // Standings0
            // 
            Standings0.AutoSize = true;
            Standings0.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            Standings0.Location = new Point(43, 481);
            Standings0.Name = "Standings0";
            Standings0.Size = new Size(23, 28);
            Standings0.TabIndex = 14;
            Standings0.Text = "0";
            // 
            // pbA1
            // 
            pbA1.BackColor = SystemColors.ControlDark;
            pbA1.Location = new Point(10, 19);
            pbA1.Name = "pbA1";
            pbA1.Size = new Size(166, 142);
            pbA1.SizeMode = PictureBoxSizeMode.CenterImage;
            pbA1.TabIndex = 15;
            pbA1.TabStop = false;
            pbA1.Click += pictureBox1_Click;
            // 
            // pbA2
            // 
            pbA2.BackColor = SystemColors.ControlDark;
            pbA2.Location = new Point(181, 20);
            pbA2.Name = "pbA2";
            pbA2.Size = new Size(166, 142);
            pbA2.SizeMode = PictureBoxSizeMode.CenterImage;
            pbA2.TabIndex = 16;
            pbA2.TabStop = false;
            // 
            // pbA3
            // 
            pbA3.BackColor = SystemColors.ControlDark;
            pbA3.Location = new Point(353, 19);
            pbA3.Name = "pbA3";
            pbA3.Size = new Size(166, 142);
            pbA3.SizeMode = PictureBoxSizeMode.CenterImage;
            pbA3.TabIndex = 17;
            pbA3.TabStop = false;
            // 
            // pbB1
            // 
            pbB1.BackColor = SystemColors.ControlDark;
            pbB1.Location = new Point(12, 166);
            pbB1.Name = "pbB1";
            pbB1.Size = new Size(166, 142);
            pbB1.SizeMode = PictureBoxSizeMode.CenterImage;
            pbB1.TabIndex = 18;
            pbB1.TabStop = false;
            // 
            // pbB2
            // 
            pbB2.BackColor = SystemColors.ControlDark;
            pbB2.Location = new Point(181, 166);
            pbB2.Name = "pbB2";
            pbB2.Size = new Size(166, 142);
            pbB2.SizeMode = PictureBoxSizeMode.CenterImage;
            pbB2.TabIndex = 19;
            pbB2.TabStop = false;
            // 
            // pbB3
            // 
            pbB3.BackColor = SystemColors.ControlDark;
            pbB3.Location = new Point(353, 167);
            pbB3.Name = "pbB3";
            pbB3.Size = new Size(166, 142);
            pbB3.SizeMode = PictureBoxSizeMode.CenterImage;
            pbB3.TabIndex = 20;
            pbB3.TabStop = false;
            // 
            // pbC1
            // 
            pbC1.BackColor = SystemColors.ControlDark;
            pbC1.Location = new Point(10, 314);
            pbC1.Name = "pbC1";
            pbC1.Size = new Size(166, 142);
            pbC1.SizeMode = PictureBoxSizeMode.CenterImage;
            pbC1.TabIndex = 21;
            pbC1.TabStop = false;
            // 
            // pbC2
            // 
            pbC2.BackColor = SystemColors.ControlDark;
            pbC2.Location = new Point(181, 314);
            pbC2.Name = "pbC2";
            pbC2.Size = new Size(166, 142);
            pbC2.SizeMode = PictureBoxSizeMode.CenterImage;
            pbC2.TabIndex = 22;
            pbC2.TabStop = false;
            // 
            // pbC3
            // 
            pbC3.BackColor = SystemColors.ControlDark;
            pbC3.Location = new Point(353, 315);
            pbC3.Name = "pbC3";
            pbC3.Size = new Size(166, 142);
            pbC3.SizeMode = PictureBoxSizeMode.CenterImage;
            pbC3.TabIndex = 23;
            pbC3.TabStop = false;
            // 
            // tbA1
            // 
            tbA1.Location = new Point(39, 123);
            tbA1.Name = "tbA1";
            tbA1.Size = new Size(100, 23);
            tbA1.TabIndex = 24;
            // 
            // tbA2
            // 
            tbA2.Location = new Point(203, 123);
            tbA2.Name = "tbA2";
            tbA2.Size = new Size(100, 23);
            tbA2.TabIndex = 25;
            // 
            // tbA3
            // 
            tbA3.Location = new Point(389, 123);
            tbA3.Name = "tbA3";
            tbA3.Size = new Size(100, 23);
            tbA3.TabIndex = 26;
            // 
            // tbB2
            // 
            tbB2.Location = new Point(206, 274);
            tbB2.Name = "tbB2";
            tbB2.Size = new Size(100, 23);
            tbB2.TabIndex = 27;
            // 
            // tbB1
            // 
            tbB1.Location = new Point(39, 274);
            tbB1.Name = "tbB1";
            tbB1.Size = new Size(100, 23);
            tbB1.TabIndex = 28;
            // 
            // tbB3
            // 
            tbB3.Location = new Point(389, 274);
            tbB3.Name = "tbB3";
            tbB3.Size = new Size(100, 23);
            tbB3.TabIndex = 29;
            // 
            // tbC1
            // 
            tbC1.Location = new Point(39, 422);
            tbC1.Name = "tbC1";
            tbC1.Size = new Size(100, 23);
            tbC1.TabIndex = 30;
            // 
            // tbC2
            // 
            tbC2.Location = new Point(203, 422);
            tbC2.Name = "tbC2";
            tbC2.Size = new Size(100, 23);
            tbC2.TabIndex = 31;
            // 
            // tbC3
            // 
            tbC3.Location = new Point(389, 422);
            tbC3.Name = "tbC3";
            tbC3.Size = new Size(100, 23);
            tbC3.TabIndex = 32;
            // 
            // Input
            // 
            Input.AutoCompleteMode = AutoCompleteMode.Suggest;
            Input.AutoCompleteSource = AutoCompleteSource.FileSystemDirectories;
            Input.Location = new Point(181, 461);
            Input.Name = "Input";
            Input.Size = new Size(166, 23);
            Input.TabIndex = 33;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(181, 481);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(166, 78);
            dataGridView1.TabIndex = 34;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(31, 481);
            label4.Name = "label4";
            label4.Size = new Size(17, 28);
            label4.TabIndex = 35;
            label4.Text = ":";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(528, 561);
            Controls.Add(label4);
            Controls.Add(dataGridView1);
            Controls.Add(Input);
            Controls.Add(tbC3);
            Controls.Add(tbC2);
            Controls.Add(tbC1);
            Controls.Add(tbB3);
            Controls.Add(tbB1);
            Controls.Add(tbB2);
            Controls.Add(tbA3);
            Controls.Add(tbA2);
            Controls.Add(tbA1);
            Controls.Add(pbC3);
            Controls.Add(pbC2);
            Controls.Add(pbC1);
            Controls.Add(pbB3);
            Controls.Add(pbB2);
            Controls.Add(pbB1);
            Controls.Add(pbA3);
            Controls.Add(pbA2);
            Controls.Add(pbA1);
            Controls.Add(Standings0);
            Controls.Add(StandingsX);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(C3);
            Controls.Add(C2);
            Controls.Add(C1);
            Controls.Add(B3);
            Controls.Add(B2);
            Controls.Add(B1);
            Controls.Add(A3);
            Controls.Add(A2);
            Controls.Add(A1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Margin = new Padding(3, 2, 3, 2);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Form1";
            ShowIcon = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Tic Tac Toe";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pbA1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbA2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbA3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbB1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbB2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbB3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbC1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbC2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pbC3).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button A1;
        private Button A2;
        private Button A3;
        private Button B3;
        private Button B2;
        private Button B1;
        private Button C3;
        private Button C2;
        private Button C1;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem newGameToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label StandingsX;
        private Label Standings0;
        private PictureBox pbA1;
        private PictureBox pbA2;
        private PictureBox pbA3;
        private PictureBox pbB1;
        private PictureBox pbB2;
        private PictureBox pbB3;
        private PictureBox pbC1;
        private PictureBox pbC2;
        private PictureBox pbC3;
        private TextBox tbA1;
        private TextBox tbA2;
        private TextBox tbA3;
        private TextBox tbB2;
        private TextBox tbB1;
        private TextBox tbB3;
        private TextBox tbC1;
        private TextBox tbC2;
        private TextBox tbC3;
        private TextBox Input;
        private DataGridView dataGridView1;
        private Label label4;
    }
}