using System.Diagnostics.Eventing.Reader;
using System.Linq.Expressions;
using System.Reflection;
using System.Security.Cryptography;
using System.Windows.Forms;
using tictactoe;


namespace tictactoe
{
    public partial class Form1 : Form
    {
        Random r = new Random();

        // Random Numbers For Flags 
        int rA1;        // Reihenaufbau
        int rA2;
        int rA3;        // A1 A2 A3
        int rB1;        // B1 B2 B3
        int rB2;        // C1 C2 C3
        int rB3;
        int rC1;
        int rC2;
        int rC3;

        // Random Flag Country Name (from countriesList array)
        string rNameA1;
        string rNameA2;
        string rNameA3;
        string rNameB1;
        string rNameB2;
        string rNameB3;
        string rNameC1;
        string rNameC2;
        string rNameC3;


        // Random Flag Path 
        string rPathA1;
        string rPathA2;
        string rPathA3;
        string rPathB1;
        string rPathB2;
        string rPathB3;
        string rPathC1;
        string rPathC2;
        string rPathC3;

        string pathEnd = ".svg";

        // Rest 
        bool turn = true; // true = x false = 0
        int turnCount = 0;

        // PictureBox define
        PictureBox pictureBoxA1 = new PictureBox();
        PictureBox pictureBoxA2 = new PictureBox();
        PictureBox pictureBoxA3 = new PictureBox();
        PictureBox pictureBoxB1 = new PictureBox();
        PictureBox pictureBoxB2 = new PictureBox();
        PictureBox pictureBoxB3 = new PictureBox();
        PictureBox pictureBoxC1 = new PictureBox();
        PictureBox pictureBoxC2 = new PictureBox();
        PictureBox pictureBoxC3 = new PictureBox();


        public Form1()
        {
            InitializeComponent();


            // random number for random flag selection

            // A
            rA1 = r.Next(0, 191);
            do
            {
                rA2 = r.Next(0, 190);
            } while (rA2 == rA1);
            do
            {
                rA3 = r.Next(0, 190);
            } while (rA3 == rA1 || rA3 == rA2);

            // B
            do
            {
                rB1 = r.Next(0, 190);
            } while (rB1 == rA1 || rB1 == rA2 || rB1 == rA3);
            do
            {
                rB2 = r.Next(0, 190);
            } while (rB2 == rA1 || rB2 == rA2 || rB2 == rA3 || rB2 == rB1);
            do
            {
                rB3 = r.Next(0, 190);
            } while (rB2 == rA1 || rB2 == rA2 || rB2 == rA3 || rB2 == rB1 || rB3 == rB2);

            // C
            do
            {
                rC1 = r.Next(0, 190);
            } while (rC1 == rA1 || rC1 == rA2 || rC1 == rA3 || rC1 == rB1 || rC1 == rB2 || rC1 == rB3);
            do
            {
                rC2 = r.Next(0, 190);
            } while (rC2 == rC1 || rC2 == rA2 || rC2 == rA3 || rC2 == rB1 || rC2 == rB2 || rC2 == rB3 || rC2 == rC1);
            do
            {
                rC3 = r.Next(0, 190);
            } while (rC3 == rC1 || rC3 == rA2 || rC3 == rA3 || rC3 == rB1 || rC3 == rB2 || rC3 == rB3 || rC3 == rC1 || rC3 == rC2);


            // Random Number to Country Name
            rNameA1 = CountryList.Countries[rA1];
            rNameA2 = CountryList.Countries[rA2];
            rNameA3 = CountryList.Countries[rA3];
            rNameB1 = CountryList.Countries[rB1];
            rNameB2 = CountryList.Countries[rB2];
            rNameB3 = CountryList.Countries[rB3];
            rNameC1 = CountryList.Countries[rC1];
            rNameC2 = CountryList.Countries[rC2];
            rNameC3 = CountryList.Countries[rC3];


            // Random Number to .resx File
            rPathA1 = rNameA1 + pathEnd;
            rPathA2 = rNameA2 + pathEnd;
            rPathA3 = rNameA3 + pathEnd;
            rPathB1 = rNameB1 + pathEnd;
            rPathB2 = rNameB2 + pathEnd;
            rPathB3 = rNameB3 + pathEnd;
            rPathC1 = rNameC1 + pathEnd;
            rPathC2 = rNameC2 + pathEnd;
            rPathC3 = rNameC3 + pathEnd;

            Image imageA1 = (Image)Properties.Resources.ResourceManager.GetObject(rPathA1);
            Image imageA2 = (Image)Properties.Resources.ResourceManager.GetObject(rPathA2);
            Image imageA3 = (Image)Properties.Resources.ResourceManager.GetObject(rPathA3);
            Image imageB1 = (Image)Properties.Resources.ResourceManager.GetObject(rPathB1);
            Image imageB2 = (Image)Properties.Resources.ResourceManager.GetObject(rPathB2);
            Image imageB3 = (Image)Properties.Resources.ResourceManager.GetObject(rPathB3);
            Image imageC1 = (Image)Properties.Resources.ResourceManager.GetObject(rPathC1);
            Image imageC2 = (Image)Properties.Resources.ResourceManager.GetObject(rPathC2);
            Image imageC3 = (Image)Properties.Resources.ResourceManager.GetObject(rPathC3);

            pbA1.Image = imageA1;
            pbA2.Image = imageA2;
            pbA3.Image = imageA3;
            pbB1.Image = imageB1;
            pbB2.Image = imageB2;
            pbB3.Image = imageB3;
            pbC1.Image = imageC1;
            pbC2.Image = imageC2;
            pbC3.Image = imageC3;

            tbA1.Text = rNameA1;
            tbA2.Text = rNameA2;
            tbA3.Text = rNameA3;
            tbB1.Text = rNameB1;
            tbB2.Text = rNameB2;
            tbB3.Text = rNameB3;
            tbC1.Text = rNameC1;
            tbC2.Text = rNameC2;
            tbC3.Text = rNameC3;
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            if (turn)
                b.Text = "X";
            else
                b.Text = "0";

            turnCount++;
            turn = !turn;
            b.Enabled = false;

            checkForWinner();
        }

        private void checkForWinner()
        {
            bool isWinner = false;

            if ((A1.Text == A2.Text) && (A2.Text == A3.Text) && (!A1.Enabled))
                isWinner = true;
            if ((B1.Text == B2.Text) && (B2.Text == B3.Text) && (!B1.Enabled))
                isWinner = true;
            if ((C1.Text == C2.Text) && (C2.Text == C3.Text) && (!C1.Enabled))
                isWinner = true;

            if ((A1.Text == B1.Text) && (B1.Text == C1.Text) && (!A1.Enabled))
                isWinner = true;
            if ((A2.Text == B2.Text) && (B2.Text == C2.Text) && (!A2.Enabled))
                isWinner = true;
            if ((A3.Text == B3.Text) && (B3.Text == C3.Text) && (!A3.Enabled))
                isWinner = true;

            if ((A1.Text == B2.Text) && (B2.Text == C3.Text) && (!A1.Enabled))
                isWinner = true;
            if ((C1.Text == B2.Text) && (B2.Text == A3.Text) && (!C1.Enabled))
                isWinner = true;

            if (isWinner)
            {
                disableButton();

                String winner = "";
                if (turn)
                {
                    winner = "0";
                    Standings0.Text = (Double.Parse(Standings0.Text) + 1).ToString();
                }
                else
                {
                    winner = "X";
                    StandingsX.Text = (Double.Parse(StandingsX.Text) + 1).ToString();
                }
                MessageBox.Show(winner + " wins", "Game ended");
            }
            else
            {
                if (turnCount == 9)
                {
                    StandingsX.Text = (Double.Parse(StandingsX.Text) + 0.5).ToString();
                    StandingsX.Text = (Double.Parse(StandingsX.Text) + 0.5).ToString();
                    MessageBox.Show("The game ended in a draw", "Game ended");
                }
            }
        }
        private void disableButton()
        {

            foreach (Control c in Controls)
            {
                try
                {
                    Button b = (Button)c;
                    b.Enabled = false;
                }
                catch { }
            }

        }

        private void newGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            turn = true;
            turnCount = 0;

            foreach (Control c in Controls)
            {
                try
                {
                    Button b = (Button)c;
                    b.Enabled = Enabled;
                    b.Text = "";
                }
                catch { }
            }
        }
        private void button_enter(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            if (b.Enabled)
            {
                if (turn)
                    b.Text = "X";
                else
                    b.Text = "0";
            }
        }
        private void button_leave(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            if (b.Enabled)
            {
                b.Text = "";
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}